using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Security.Claims;
using System.Text;
using VinilaShop_ASP.Models;
using System.Security.Cryptography;

namespace VinilaShop_ASP.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private VinisopContext db;

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
            }
        }

        public HomeController(ILogger<HomeController> logger, VinisopContext context)
        {
            _logger = logger;
            db = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(string login, string password)
        {
            string haspassword = HashPassword(password);
            var user = db.Users.FirstOrDefault(u => u.Email == login && u.PasswordHash == haspassword);
            if (user != null)
            {
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user.FullName),
                    new Claim(ClaimTypes.Role , user.RoleId==2 ? "Customer" : "OtherRole" )
                };

                var claimsIdent = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var claimsPrincipal = new ClaimsPrincipal(claimsIdent);
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, claimsPrincipal);
                return RedirectToAction("Index", "Catalog");
            }
            ViewBag.ErrorMessage = "�������� ������� ������";
            return View();
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();

        }

        [HttpPost]
        public async Task<IActionResult> Register(string Fullname, string email, string phone, string password)
        {
            if (db.Users.Any(u => u.Email == email))
            {
                ViewBag.ErrorMesage = "������������ � ����� email ��� ����������";
                return View();
            }
            string hashedpassword = HashPassword(password);

            var user = new User
            {
                FullName = Fullname,
                Email = email,
                Phone = phone,
                PasswordHash = hashedpassword,
                DateJoined = DateTime.Now,
                RoleId = 2
            };
            db.Users.Add(user);
            await db.SaveChangesAsync();
            return RedirectToAction("Index", "Home");
        }






        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
