﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using VinilaShop_ASP.Models;
using System.Linq;

namespace VinilaShop_ASP.Controllers
{
    public class Basket : Controller
    {
        private readonly VinisopContext db;

        public Basket(VinisopContext context)
        {
            db = context;
        }

        public IActionResult Index()
        {
            var basketCookie = Request.Cookies["Basket"];
            var basketData = string.IsNullOrEmpty(basketCookie)
                ? new Dictionary<int, int>()
                : JsonConvert.DeserializeObject<Dictionary<int, int>>(basketCookie);

            // Получаем список продуктов, добавленных в корзину
            var products = db.Products
                             .Where(p => basketData.Keys.Contains(p.IdProduct))
                             .ToList();

            // Подсчитываем общую сумму корзины
            ViewBag.TotalAmount = products.Sum(p => p.Price * basketData[p.IdProduct]);

            // Отправляем данные корзины в представление
            ViewBag.BasketData = basketData;
            return View(products);
        }

        [HttpPost]
        public IActionResult Add(int productId, int quantity)
        {
            var product = db.Products.Find(productId);
            if (product == null) return NotFound();

            // Получаем данные из корзины пользователя (Cookie)
            var basketCookie = Request.Cookies["Basket"];
            var basketData = string.IsNullOrEmpty(basketCookie)
                ? new Dictionary<int, int>()
                : JsonConvert.DeserializeObject<Dictionary<int, int>>(basketCookie);

            // Обновляем количество товара в корзине
            if (basketData.ContainsKey(productId))
                basketData[productId] += quantity;
            else
                basketData[productId] = quantity;

            // Обновляем Cookie с новыми данными корзины
            var options = new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.Now.AddDays(7) // корзина будет храниться 7 дней
            };
            Response.Cookies.Append("Basket", JsonConvert.SerializeObject(basketData), options);

            // Перенаправляем на страницу корзины
            return RedirectToAction("Index", "Basket");
        }

        [HttpPost]
        public IActionResult Update(int productId, int quantity)
        {
            var basketCookie = Request.Cookies["Basket"];
            var basketData = string.IsNullOrEmpty(basketCookie)
                ? new Dictionary<int, int>()
                : JsonConvert.DeserializeObject<Dictionary<int, int>>(basketCookie);

            if (basketData.ContainsKey(productId))
            {
                basketData[productId] -= quantity;
                if (basketData[productId] <= 0)
                {
                    basketData.Remove(productId); // Удаляем товар, если количество <= 0
                }
            }

            var options = new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.Now.AddDays(7)
            };
            Response.Cookies.Append("Basket", JsonConvert.SerializeObject(basketData), options);

            return RedirectToAction("Index", "Basket");
        }

        public IActionResult Clear()
        {
            // Удаляем корзину из Cookie
            Response.Cookies.Delete("Basket");
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Delete(int productId)
        {
            // Получаем данные из корзины пользователя (Cookie)
            var basketCookie = Request.Cookies["Basket"];
            var basketData = string.IsNullOrEmpty(basketCookie)
                ? new Dictionary<int, int>()
                : JsonConvert.DeserializeObject<Dictionary<int, int>>(basketCookie);

            // Удаляем товар из корзины
            if (basketData.ContainsKey(productId))
            {
                basketData.Remove(productId);
            }

            // Обновляем Cookie с новыми данными корзины
            var options = new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.Now.AddDays(7)
            };
            Response.Cookies.Append("Basket", JsonConvert.SerializeObject(basketData), options);

            // Перенаправляем на страницу корзины
            return RedirectToAction("Index", "Basket");
        }
    }
}
