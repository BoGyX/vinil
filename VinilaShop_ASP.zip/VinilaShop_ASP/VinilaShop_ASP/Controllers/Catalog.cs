﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using VinilaShop_ASP.Models;

namespace VINISOP.Controllers
{
    public class CatalogController : Controller
    {
        private VinisopContext db;

        public CatalogController(VinisopContext context)
        {
            db = context;
        }

        public async Task<IActionResult> Index(string searchQuery, string category, decimal? minPrice, decimal? maxPrice, string sortOrder)
        {
            var userName = User.Identity?.Name ?? "Гость";
            ViewBag.Greeting = $"Здравствуйте, {userName}";

            var products = db.Products
                             .Include(p => p.Category)
                             .Include(p => p.Manufacturer)
                             .Include(p => p.Artist)
                             .AsQueryable();

            // Фильтры
            if (!string.IsNullOrEmpty(searchQuery))
            {
                products = products.Where(p => p.NameProduct.Contains(searchQuery));
            }

            if (!string.IsNullOrEmpty(category))
            {
                products = products.Where(p => p.Category.NameCategory == category);
            }

            if (minPrice.HasValue)
            {
                products = products.Where(p => p.Price >= minPrice.Value);
            }

            if (maxPrice.HasValue)
            {
                products = products.Where(p => p.Price <= maxPrice.Value);
            }

            // Сортировка
            switch (sortOrder)
            {
                case "price_asc":
                    products = products.OrderBy(p => p.Price);
                    break;
                case "price_desc":
                    products = products.OrderByDescending(p => p.Price);
                    break;
                case "name_asc":
                    products = products.OrderBy(p => p.NameProduct);
                    break;
                case "name_desc":
                    products = products.OrderByDescending(p => p.NameProduct);
                    break;
                default:
                    products = products.OrderBy(p => p.NameProduct);
                    break;
            }

            // Передача данных в представление
            ViewBag.Categories = db.Categories.ToList();
            ViewBag.SearchQuery = searchQuery;
            ViewBag.Category = category;
            ViewBag.MinPrice = minPrice;
            ViewBag.MaxPrice = maxPrice;
            ViewBag.SortOrder = sortOrder;

            return View(await products.ToListAsync());
        }
    }
}
