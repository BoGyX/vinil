﻿using System;
using System.Collections.Generic;

namespace VinilaShop_ASP.Models;

public partial class Artist
{
    public int IdArtist { get; set; }

    public string NameArtist { get; set; } = null!;

    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
