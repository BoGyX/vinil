﻿using System;
using System.Collections.Generic;

namespace VinilaShop_ASP.Models;

public partial class Product
{
    public int IdProduct { get; set; }

    public string NameProduct { get; set; } = null!;

    public int? ArtistId { get; set; }

    public int ReleaseYear { get; set; }

    public int? CategoryId { get; set; }

    public int? ManufacturerId { get; set; }

    public decimal Price { get; set; }

    public int? StockQuantity { get; set; }

    public int? WarehouseId { get; set; }

    public string? ImageUrl { get; set; }

    public virtual Artist? Artist { get; set; }

    public virtual ICollection<Basket> Baskets { get; set; } = new List<Basket>();

    public virtual Category? Category { get; set; }

    public virtual Manufacturer? Manufacturer { get; set; }

    public virtual ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();

    public virtual Warehouse? Warehouse { get; set; }
}
